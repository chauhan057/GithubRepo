package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Repository> repositoryList;
    private RepositoryAdapter repositoryAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        repositoryList = new ArrayList<>(); // Initialize your repository list
        Intent intent=getIntent();
        String repo=intent.getStringExtra("repo");
        String desc=intent.getStringExtra("desc");
        String owner=intent.getStringExtra("owner");
        Repository res=new Repository(repo,desc,owner);
        repositoryList.add(res);
        repositoryAdapter = new RepositoryAdapter(repositoryList);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(repositoryAdapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_add_repo) {

            Intent intent = new Intent(this, AddRepo.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}